/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package queryrunner;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.stream.IntStream;

/**
 * IMPROVEMENTS:
 * 1. QueryFrame.java:
 * - clean the code and follow warning to improve code
 * - Add btnToCSV and jCheckBox to develop new feature
 * - Add a background image to imporve the layout
 * 2. QueryRunner.java:
 * - Create console mode to run query in command line
 * - updated the Query list to use our query
 * - Add documentation to each function
 * 3. QueryData.java:
 * - Remove command out code, clean the code
 */
public class QueryRunner {

    public QueryRunner() {
        this.m_jdbcData = new QueryJDBC();
        m_updateAmount = 0;
        m_queryArray = new ArrayList<>();
        m_error = "";

        // Project name
        this.m_projectTeamApplication = "Movie Database";

        // Query 1
        m_queryArray.add(new QueryData(
                "SELECT m.movie_name, m.movie_releaseDate, m.movie_director " +
                        "FROM Movie m",
                null,
                null,
                false,
                false
        ));

        // Query 2
        m_queryArray.add(new QueryData(
                "SELECT m.movie_name, r.rating_review FROM Movie m " +
                        "INNER JOIN Rating r ON m.movie_id = r.movie_id " +
                        "WHERE m.movie_id = ? AND r.rating_review IS NOT NULL",
                new String[]{"movie_id"},
                new boolean[]{false},
                false,
                true
        ));

        // Query 3
        m_queryArray.add(new QueryData(
                "SELECT distinct user_firstname, movie_name FROM User u " +
                        "INNER JOIN Favorite f ON u.user_id = f.user_id " +
                        "INNER JOIN Movie m ON m.movie_id = f.movie_id " +
                        "WHERE u.user_id = ?",
                new String[]{"user_id"},
                new boolean[]{false},
                false,
                true
        ));

        // Query 4
        m_queryArray.add(new QueryData(
                "SELECT g.genres_name, m.movie_name " +
                        "FROM Genres g INNER JOIN Genres_Movie gm ON g.genres_id = gm.genres_id " +
                        "INNER JOIN Movie m ON gm.movie_id = m.movie_id " +
                        "WHERE g.genres_id = ?",
                new String[]{"genres_id"},
                new boolean[]{false},
                false,
                true
        ));

        // Query 5
        m_queryArray.add(new QueryData(
                "SELECT a.actor_fname,a.actor_lname, am.char_name, m.movie_name FROM Actor a " +
                        "INNER JOIN Actor_Movie am ON a.actor_id = am.actor_id " +
                        "INNER JOIN Movie m ON am.movie_id = m.movie_id " +
                        "WHERE a.actor_id = ?",
                new String[]{"actor_id"},
                new boolean[]{false},
                false,
                true
        ));

        // Query 6
        m_queryArray.add(new QueryData(
                "SELECT w.writer_fname, s.school_name FROM Writer w " +
                        "INNER JOIN School s ON w.school_id = s.school_id " +
                        "WHERE s.school_id = ?",
                new String[]{"school_id"},
                new boolean[]{false},
                false,
                true
        ));

        // Query 7
        m_queryArray.add(new QueryData(
                "SELECT m.movie_name, e.Event_address FROM Event e " +
                        "INNER JOIN Movie m ON m.Event_id = e.Event_id " +
                        "WHERE e.Event_id = ?",
                new String[]{"Event_id"},
                new boolean[]{false},
                false,
                true
        ));

        // Query 8
        m_queryArray.add(new QueryData(
                "SELECT u.user_firstname, a.RATING_COUNT FROM ( " +
                        "SELECT user_id, count(rating_rate) RATING_COUNT FROM Rating " +
                        "GROUP BY user_id " +
                        "ORDER BY RATING_COUNT desc" +
                        ") a INNER JOIN User u ON a.user_id = u.user_id LIMIT 1",
                null,
                null,
                false,
                true
        ));

        // Query 9
        m_queryArray.add(new QueryData(
                "SELECT u.user_firstname, s.school_name FROM User u " +
                        "INNER JOIN School s ON u.school_id = s.school_id " +
                        "WHERE s.school_id = ?",
                new String[]{"school_id"},
                new boolean[]{false},
                false,
                true
        ));

        // Query 10
        m_queryArray.add(new QueryData(
                "SELECT m.movie_name, e.event_address FROM Movie m " +
                        "INNER JOIN Event e ON m.event_id = e.event_id " +
                        "WHERE e.event_date = \"?-?-?\"",
                new String[]{"Year", "Month", "Day"},
                new boolean[]{false, false, false},
                false,
                true
        ));

        // Query 11
        m_queryArray.add(new QueryData(
                "INSERT INTO Movie (" +
                        "movie_name, " +
                        "movie_length, " +
                        "movie_releaseDate, " +
                        "movie_director, " +
                        "Event_id, " +
                        "movie_language, " +
                        "writer_id" +
                        ") VALUES (?, ? , ?, ?, ?, ?, 1)",
                new String[]{
                        "movie_name",
                        "movie_length",
                        "movie_releaseDate",
                        "movie_director",
                        "Event_id",
                        "movie_language"
                },
                new boolean[]{false, false, false, false, false, false},
                true,
                true
        ));
    }


    /**
     * returns the total number of queries
     *
     * @return total number of queries
     */
    public int GetTotalQueries() {
        return m_queryArray.size();
    }

    /**
     * returns the total number of queries
     *
     * @return total number of queries
     */
    public int GetParameterAmtForQuery(int queryChoice) {
        QueryData e = m_queryArray.get(queryChoice);
        return e.GetParmAmount();
    }

    /**
     * returns the total number of queries
     *
     * @return total number of queries
     */
    public String GetParamText(int queryChoice, int parmnum) {
        QueryData e = m_queryArray.get(queryChoice);
        return e.GetParamText(parmnum);
    }

    /**
     * returns the total number of queries
     *
     * @return total number of queries
     */
    public String GetQueryText(int queryChoice) {
        QueryData e = m_queryArray.get(queryChoice);
        return e.GetQueryString();
    }

    /**
     * Function will return how many rows were updated as a result
     * of the update query
     *
     * @return Returns how many rows were updated
     */

    public int GetUpdateAmount() {
        return m_updateAmount;
    }

    /**
     * Function will return ALL of the Column Headers from the query
     *
     * @return Returns array of column headers
     */
    public String[] GetQueryHeaders() {
        return m_jdbcData.GetHeaders();
    }

    /**
     * After the query has been run, all of the data has been captured into
     * a multi-dimensional string array which contains all the row's. For each
     * row it also has all the column data. It is in string format
     *
     * @return multi-dimensional array of String data based on the resultset
     * from the query
     */
    public String[][] GetQueryData() {
        return m_jdbcData.GetData();
    }

    /**
     * @return m_projectTeamApplication
     */
    public String GetProjectTeamApplication() {
        return m_projectTeamApplication;
    }

    /**
     * checks to see if given query is an action query or not
     *
     * @param queryChoice query to check
     * @return if query is param or not
     */
    public boolean isActionQuery(int queryChoice) {
        QueryData e = m_queryArray.get(queryChoice);
        return e.IsQueryAction();
    }

    /**
     * checks to see if given query is parameter query or not
     *
     * @param queryChoice query to check
     * @return if query is param or not
     */
    public boolean isParameterQuery(int queryChoice) {
        QueryData e = m_queryArray.get(queryChoice);
        return e.IsQueryParm();
    }

    /**
     * executes the query.
     *
     * @param queryChoice query to execute
     * @param parms       params in query
     * @return true if successful, false otherwise
     */
    public boolean ExecuteQuery(int queryChoice, String[] parms) {
        QueryData e = m_queryArray.get(queryChoice);
        return m_jdbcData.ExecuteQuery(e.GetQueryString(), parms, e.GetAllLikeParams());
    }

    public boolean ExecuteUpdate(int queryChoice, String[] parms) {
        QueryData e = m_queryArray.get(queryChoice);
        boolean bOK = m_jdbcData.ExecuteUpdate(e.GetQueryString(), parms);
        m_updateAmount = m_jdbcData.GetUpdateCount();
        return bOK;
    }

    /**
     * connects the user to the database for queries.
     *
     * @param szHost     hostname for connection
     * @param szUser     username for connection
     * @param szPass     password for connection
     * @param szDatabase database for connection
     * @return true if connection was successful, false otherwise
     */
    public boolean Connect(String szHost, String szUser, String szPass, String szDatabase) {

        boolean bConnect = m_jdbcData.ConnectToDatabase(szHost, szUser, szPass, szDatabase);
        if (!bConnect)
            m_error = m_jdbcData.GetError();
        return bConnect;
    }

    /**
     * disconnects the user from the database
     *
     * @return true if disconnect was fine, false if there was an error
     */
    public boolean Disconnect() {
        // Disconnect the JDBCData Object
        boolean bConnect = m_jdbcData.CloseDatabase();
        if (!bConnect)
            m_error = m_jdbcData.GetError();
        return true;
    }

    /**
     * returns what error occurred.
     *
     * @return string of errortype.
     */
    public String GetError() {
        return m_error;
    }

    private QueryJDBC m_jdbcData;
    private String m_error;
    private String m_projectTeamApplication;
    private ArrayList<QueryData> m_queryArray;
    private int m_updateAmount;

    /**
     * displays a menu showing what queries the user can choose to run.
     */
    public static void displayMenu() {
        System.out.println("Choose the query number to run: ");
        System.out.println("1   List all movies in database");
        System.out.println("2   List all reviews of one movie");
        System.out.println("3   List all favorites movies of one user");
        System.out.println("4   List all moives contains one genres");
        System.out.println("5   List all moives that one actor plays");
        System.out.println("6   List all writers from one school");
        System.out.println("7   List all movies play in one event");
        System.out.println("8   Find the user left most reviews");
        System.out.println("9   List the users from one school");
        System.out.println("10  List all movies play in one particular day");
        System.out.println("11  Create a new movie");
        System.out.println("12  Exit the program\n");
        System.out.print("Enter your choice: ");
    }

    /**
     * Returns the choice of query the user makes.
     *
     * @param sc scanner for user input
     * @return int of user's choice
     */
    public int getChoice(Scanner sc) {
        displayMenu();
        ArrayList<Integer> valid = new ArrayList<>();
        // create an array to valid the input
        IntStream.range(1, 13).forEach(valid::add);
        String choice = sc.nextLine();

        while (choice.length() == 0 || !valid.contains(Integer.parseInt(choice))) {
            System.out.println("Invalid choice entry, please try again.\n");
            clearConsole();
            displayMenu();
            choice = sc.nextLine();
        }
        return Integer.parseInt(choice);
    }

    /**
     * Prints out the query associated with the option selected by the user.
     *
     * @param result      query result
     * @param header      for printing out the results to console
     * @param columnSpace space of each column
     */
    public void formatPrint(String[][] result, String[] header, int[] columnSpace) {
        StringBuilder f;
        ArrayList<String> format = new ArrayList<>();
        for (int j : columnSpace) {
            f = new StringBuilder();
            f.append("|");
            f.append("%-");
            f.append(j);
            f.append("s");
            format.add(f.toString());
        }
        for (int j : columnSpace) {
            System.out.print("+");
            for (int i = 0; i < j; i++)
                System.out.print("-");
        }
        System.out.print("+\n");
        int i = 0;
        for (String form : format) {
            System.out.printf(form, header[i]);
            i += 1;
        }
        System.out.print("|\n");
        for (int j : columnSpace) {
            System.out.print("+");
            for (i = 0; i < j; i++)
                System.out.print("-");
        }
        System.out.print("+\n");
        for (String[] row : result) {
            i = 0;
            for (String form : format)
                System.out.printf(form, row[i++]);
            System.out.print("|\n");
        }
        for (int j : columnSpace) {
            System.out.print("+");
            for (i = 0; i < j; i++)
                System.out.print("-");
        }
        System.out.print("+\n");
    }

    /**
     * Prints out the query associated with the option selected by the user.
     *
     * @param result      query result
     * @param header      for printing out the results to console
     * @param queryNumber number determining query to run
     */
    public void printQuery(String[][] result, String[] header, int queryNumber) {
        clearConsole();
        switch (queryNumber + 1) {
            case 1: //SELECT m.movie_name, m.movie_releaseDate, m.movie_director
                int[] f1 = {45, 30, 20};
                formatPrint(result, header, f1);
                break;
            case 2: //SELECT m.movie_name, r.rating_review
                int[] f2 = {45, 20};
                formatPrint(result, header, f2);
                break;
            case 3: //SELECT distinct user_firstname, movie_name
            case 4: //g.genres_name, m.movie_name
                int[] f3 = {30, 45};
                formatPrint(result, header, f3);
                break;
            case 5: //SELECT a.actor_fname,a.actor_lname, am.char_name, m.movie_name
                int[] f5 = {45, 45, 45, 45};
                formatPrint(result, header, f5);
                break;
            case 6: //SELECT w.writer_fname, s.school_name
            case 9: //SELECT u.user_firstname, s.school_name
                int[] f6 = {45, 45};
                formatPrint(result, header, f6);
                break;
            case 7: //SELECT m.movie_name, e.Event_address
            case 10: //SELECT m.movie_name, e.event_address
            case 11: //SELECT m.movie_name, e.event_address
                int[] f7 = {45, 60};
                formatPrint(result, header, f7);
                break;
            case 8: //SELECT u.user_firstname, a.RATING_COUNT
                int[] f8 = {45, 4};
                formatPrint(result, header, f8);
                break;
            default:
                break;
        }
    }

    /**
     * Runs the queries.
     *
     * @param queryrunner window to run queries
     * @param sc          for reading the query output
     * @param queryNumber for which query to run
     */
    public void getQuery(QueryRunner queryrunner, Scanner sc, int queryNumber) {
        queryNumber -= 1;

        int amt = queryrunner.GetParameterAmtForQuery(queryNumber);
        String[] params = new String[amt];

        if (queryrunner.isParameterQuery(queryNumber)) {

            for (int i = 0; i < params.length; i++) {
                String paramName = queryrunner.GetParamText(queryNumber, i);
                System.out.print("Please enter " + paramName + ": ");
                params[i] = sc.nextLine();
            }
        }

        if (queryrunner.isActionQuery(queryNumber)) {
            if (queryrunner.ExecuteUpdate(queryNumber, params)) {
                int changed = queryrunner.GetUpdateAmount();
                System.out.println("Success: " + changed + " rows were updated.");
            } else {
                System.out.println("Error: 0 rows were updated.");
            }
        } else {
            if (queryrunner.ExecuteQuery(queryNumber, params)) {
                String[][] result = queryrunner.GetQueryData();
                String[] header = queryrunner.GetQueryHeaders();
                queryrunner.printQuery(result, header, queryNumber);
            } else {
                System.out.println("Error: 0 rows were found.");
            }
        }
        System.out.println();
    }

    /**
     * print welcome message
     */
    public static void clearConsole() {
        try {
            if (System.getProperty("os.name").contains("Windows")) {
                new ProcessBuilder("cmd", "/c", "cls")
                        .inheritIO()
                        .start()
                        .waitFor();
            } else {
                System.out.print("\033\143");
            }
        } catch (IOException | InterruptedException ex) {
            System.out.print("error");
        }
        System.out.println(
                "\n+-----------------------------------------------------------------------+\n" +
                        "|    ____                            ___                                |\n" +
                        "|   / __ \\ __ __ ___   ____  __ __  / _ \\ __ __  ___   ___  ___   ____  |\n" +
                        "|  / /_/ // // // -_) / __/ / // / / , _// // / / _ \\ / _ \\/ -_) / __/  |\n" +
                        "|  \\___\\_\\\\_,_/ \\__/ /_/    \\_, / /_/|_| \\_,_/ /_//_//_//_/\\__/ /_/     |\n" +
                        "|                          /___/                                        |\n" +
                        "+-----------------------------------------------------------------------+\n\n"
        );
    }

    /**
     * print goodbye message
     */
    public static void printGoodbye() {
        try {
            if (System.getProperty("os.name").contains("Windows")) {
                new ProcessBuilder("cmd", "/c", "cls")
                        .inheritIO()
                        .start()
                        .waitFor();
            } else {
                System.out.print("\033\143");
            }
        } catch (IOException | InterruptedException ex) {
            System.out.print("error");
        }
        System.out.println(
                "\n\n\n             Thanks for using Movie Database\n" +
                        "\n" +
                        "\n" +
                        "                O          .\n" +
                        "             O            ' '\n" +
                        "               o         '   .\n" +
                        "             o         .'\n" +
                        "          __________.-'       '...___\n" +
                        "       .-'                      ###  '''...__\n" +
                        "      /   ===                ###            ''--.._ ______\n" +
                        "      '.                     #     ########        '   .-'\n" +
                        "        '-._          ..**********####  ___...---'''\\   '\n" +
                        "            '-._     __________...---'''             \\   l\n" +
                        "                \\   |                         orca    '._|\n" +
                        "                 \\__;\n\n\n\n\n"
        );
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        QueryRunner queryrunner = new QueryRunner();

        if (args.length >= 1 && args[0].equals("-console")) {
            boolean connect = false;
            String next = "Y";
            // Start to log in
            while (!connect && !next.equals("N")) {
                clearConsole();
                System.out.println("Enter info to connect to the database.");
                System.out.print("Hostname: ");
                String connection = sc.nextLine();
                System.out.print("Username: ");
                String username = sc.nextLine();
                System.out.print("Password: ");
                String password = sc.nextLine();
                System.out.print("Database: ");
                String db = sc.nextLine();
                connect = queryrunner.Connect(connection, username, password, db);
                if (!connect) {
                    System.out.println("Error: " + queryrunner.GetError());
                    System.out.print("Do you want to try again? (Y/N)");
                    next = sc.nextLine();
                }
            }

            int queryNumber = 0;
            while (!next.equals("N") && queryNumber != 12) {
                clearConsole();
                // print the menu and catch the choice
                queryNumber = queryrunner.getChoice(sc);
                if (queryNumber != 12) {
                    // runs the query, prompting the client for parameters, if necessary
                    queryrunner.getQuery(queryrunner, sc, queryNumber);
                    // ask if user wants to continue
                    System.out.print("\n\nContinue for next query? (Y/[N])");
                    next = sc.nextLine();
                }
            }

            if (!queryrunner.Disconnect()) {
                System.out.println("Error: " + queryrunner.GetError());
            }
            //print goodbye message
            printGoodbye();
            System.out.print("     Press ENTER to continue...");
            sc.nextLine();
            sc.close();
            try {
                if (System.getProperty("os.name").contains("Windows")) {
                    new ProcessBuilder("cmd", "/c", "cls")
                            .inheritIO()
                            .start()
                            .waitFor();
                } else {
                    System.out.print("\033\143");
                }
            } catch (IOException | InterruptedException ex) {
                System.out.print("error");
            }
            return;
        }

        java.awt.EventQueue.invokeLater(() -> {
            QueryFrame qf;
            try {
                qf = new QueryFrame(queryrunner);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            qf.setSize(1040, 690);
            qf.setVisible(true);
        });
    }
}